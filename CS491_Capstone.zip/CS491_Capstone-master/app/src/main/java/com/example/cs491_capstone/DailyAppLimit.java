package com.example.cs491_capstone;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.MenuItem;
import android.widget.LinearLayout;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceCategory;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class DailyAppLimit extends AppCompatActivity {

    public static List<AppList> appListObjects = new ArrayList<AppList>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parental_control);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.parental_settings, new ParentalControlFragment())
                .commit();
        Log.d("onCreate setting called", "onCreate setting called");
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

    }



    public static class ParentalControlFragment extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.daily_app_preferences, rootKey);
            setupSharedPreferences();
            Log.d("onCreate called", "onCreate called");
//            Preference myPref = (Preference) findPreference("app_limit");
//            myPref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
//                public boolean onPreferenceClick(Preference preference) {
//                    Intent i= new Intent(getActivity(), DailyAppLimit.class);
//                    Log.d("DailyAppLimit called", "DailyAppLimit called");
//                    startActivity(i);
//                    return true;
//                }
//            });
//
            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);



//            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> pkgAppsList = getActivity().getPackageManager().queryIntentActivities(mainIntent, 0);
            List<String> parseAppNames = new ArrayList<String>();
            List<Drawable> icons = new ArrayList<Drawable>();
            for(ResolveInfo i: pkgAppsList)
            {
                //parse after apps, captilize
                if(i.activityInfo.name.contains(".apps."))
                {
                    String str = ((i.activityInfo.name).split(Pattern.quote(".apps."))[1]).split(Pattern.quote("."))[0];
                    String output = str.substring(0, 1).toUpperCase() + str.substring(1);
                    if(!parseAppNames.contains(output))
                    {
                        parseAppNames.add(output);
                        icons.add(i.loadIcon(getActivity().getPackageManager()));
                    }

                }
                //parse after android, captilize
                else if(i.activityInfo.name.contains(".android."))
                {
                    String str = ((i.activityInfo.name).split(Pattern.quote(".android."))[1]).split(Pattern.quote("."))[0];
                    String output = str.substring(0, 1).toUpperCase() + str.substring(1);
                    if(!parseAppNames.contains(output))
                    {
                        parseAppNames.add(output);
                        icons.add(i.loadIcon(getActivity().getPackageManager()));
                    }
                }
                //parse last segment
                else
                {
                    String str = (i.activityInfo.toString().split("\\.") [i.activityInfo.toString().split("\\.").length - 1]).split(Pattern.quote("}"))[0];
                    String output = str.substring(0, 1).toUpperCase() + str.substring(1);
                    if(!parseAppNames.contains(output))
                    {
                        parseAppNames.add(output);
                        icons.add(i.loadIcon(getActivity().getPackageManager()));
                    }
                }
            }
            for(int i = 0; i<parseAppNames.size(); i++)
            {
                Log.d("App name: ", parseAppNames.get(i));
                AppList a = new AppList(parseAppNames.get(i), icons.get(i));
                appListObjects.add(a);

            }


            PreferenceScreen screen = getPreferenceManager().getPreferenceScreen();


        PreferenceCategory p = new PreferenceCategory(getActivity());
        p.setTitle("App Limits");
            screen.addPreference(p);
        for(AppList a: appListObjects) {
        ListPreference listPref = new ListPreference(getActivity());
        listPref.setTitle(a.getName());
        listPref.setIcon(a.getIcon());
Log.d("Icon", a.getIcon().toString());

        p.addPreference(listPref);

        }

            setPreferenceScreen(screen);
        }

        @Override
        public void onResume (){
            super.onResume();
            if (GlobalVariable.dark_mode == true)
            {
                if(getActivity() != null) {
                    Log.d("Activity", getActivity().toString());
                    LinearLayout lLayout1 = (LinearLayout) getActivity().findViewById(R.id.parental);
                    lLayout1.setBackgroundColor(Color.parseColor("#4D4E4F"));
                }
            }
            else if(GlobalVariable.dark_mode == false)
            {
                if(getActivity() != null) {
                    Log.d("Activity", getActivity().toString());
                    LinearLayout lLayout1 = (LinearLayout) getActivity().findViewById(R.id.parental);
                    lLayout1.setBackgroundColor(Color.parseColor("#FFFFFF"));
                }
            }


        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

            if (key.toString().equals("Wifi")) {
                if(getActivity() != null) {
                    WifiManager wifi = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    wifi.setWifiEnabled(false);//logic to change Wifi settings

                    if (sharedPreferences.getBoolean("Wifi", true) == false) {
                        WifiManager wifi1 = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                        wifi1.setWifiEnabled(false);
                        Log.d("Wifi turned off", "wifi Turned off");
                    } else if (sharedPreferences.getBoolean("Wifi", true) == true) {
                        WifiManager wifi1 = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                        wifi1.setWifiEnabled(true);
                        Log.d("Wifi turned on", "wifi Turned on");
                    }
                }
            }

        }

        private void setupSharedPreferences() {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
            sharedPreferences.registerOnSharedPreferenceChangeListener(this);
        }

    }
    public boolean onOptionsItemSelected(MenuItem item){
        this.onBackPressed();
        return true;
    }


}