package com.example.cs491_capstone.ui.settings;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import com.example.cs491_capstone.App;
import com.example.cs491_capstone.DailyAppLimit;
import com.example.cs491_capstone.GlobalVariable;
import com.example.cs491_capstone.R;
import com.nbsp.materialfilepicker.MaterialFilePicker;
import com.nbsp.materialfilepicker.ui.FilePickerActivity;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import static android.app.Activity.RESULT_OK;
import static com.example.cs491_capstone.App.localDatabase;

public class SettingsFragment extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int RESULT_CODE_FILE = 10123;
    private static int dbSize;
    NotificationManagerCompat notificationManagerCompat;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.settings, rootKey);
        setupSharedPreferences();
        dbSize = localDatabase.getRowCount();
        notificationManagerCompat = NotificationManagerCompat.from(getContext());




        Preference myPref1 = (Preference) findPreference("app_limit");
        myPref1.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                Intent i= new Intent(getActivity(), DailyAppLimit.class);
                Log.d("DailyApp called", "Dailyapp called");
                startActivity(i);
                return true;
            }
        });

        Preference exportCSV = findPreference("export_csv");
        exportCSV.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {

                putCSV();

                return true;
            }
        });


        Preference importCSV = findPreference("import_csv");
        importCSV.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                getCSV();

                return true;
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 123) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {


            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_CODE_FILE && resultCode == RESULT_OK) {

            new ImportCSV().execute(data);
        }
    }

    private void getCSV() {
        if (ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

            new MaterialFilePicker()
                    .withSupportFragment(this)
                    .withRequestCode(RESULT_CODE_FILE)
                    .withFilter(Pattern.compile(".*\\.csv$")) // Filtering files and directories by file name using regexp
                    //.withFilterDirectories(false) // Set directories filterable (false by default)
                    .withHiddenFiles(false) // Show hidden files and folders
                    .start();


        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE)) {
                new AlertDialog.Builder(getActivity())
                        .setTitle("Permission Needed")
                        .setMessage("CSV must be loaded from storage")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 123);

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .create().show();

            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 123);
            }
        }

    }

    private void putCSV() {
        if (ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

            NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), App.CHANNEL_2_ID_ALERTS)
                    .setSmallIcon(R.drawable.bn_icon_home)
                    .setContentTitle("Download")
                    .setContentText("Download in Progress")
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setProgress(dbSize, 0, false);


            notificationManagerCompat.notify(3, notification.build());

            new ExportCSV().execute(notification);
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                new AlertDialog.Builder(getActivity())
                        .setTitle("Permission Needed")
                        .setMessage("CSV must be loaded to storage")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 123);

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .create().show();

            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 123);
            }
        }

    }


    private class ExportCSV extends AsyncTask<NotificationCompat.Builder, Integer, String> {


        @Override
        protected String doInBackground(NotificationCompat.Builder... notifications) {
            SystemClock.sleep(1000);

            NotificationCompat.Builder notification = notifications[0];
            File exportDir = new File(Environment.getExternalStorageDirectory(), "Download");
            if (!exportDir.exists()) {
                exportDir.mkdirs();
            }

            File file = new File(exportDir, "USAGE-" + App.DATE + ".csv");

            Log.i("VALUES", "" + file);
            try {
                file.createNewFile();
                CSVWriter csvWrite = new CSVWriter(new FileWriter(file));
                Cursor curCSV = localDatabase.getAllData();
                csvWrite.writeNext(curCSV.getColumnNames());
                Log.i("VALUES", "ColumnNames" + Arrays.toString(curCSV.getColumnNames()));
                int line = 0;
                while (curCSV.moveToNext()) {


                    String[] arrStr = {curCSV.getString(0),
                            curCSV.getString(1),
                            curCSV.getString(2),
                            curCSV.getString(3),
                            curCSV.getString(4),
                            curCSV.getString(5),
                            String.format(Locale.ENGLISH, "%.0f", curCSV.getFloat(6))};
                    csvWrite.writeNext(arrStr);
                    line++;

                    notification.setProgress(dbSize, line, false)
                            .setOngoing(false);
                    notificationManagerCompat.notify(3, notification.build());

                    Log.i("VALUES", "" + Arrays.toString(arrStr));
                }

                notification.setContentText("Download Finished")
                        .setProgress(0, 0, false);
                notificationManagerCompat.notify(3, notification.build());


                csvWrite.close();
                curCSV.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return file.getPath();
        }
    }

    private class ImportCSV extends AsyncTask<Intent, Integer, String> {

        @Override
        protected String doInBackground(Intent... intents) {
            Intent data = intents[0];
            String message = null;
            IllegalArgumentException exception = new IllegalArgumentException("Headers are not in correct order");
            String filePath = data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH);
            Log.i("VALUES", "PATH:" + filePath);
            try {
                List<String> rowData;
                CSVReader reader = new CSVReader(new FileReader(new File(filePath)));
                String[] nextLine;
                int header = 0;
                while ((nextLine = reader.readNext()) != null) {
                    rowData = new ArrayList<>();
                    for (String s : nextLine) {
                        if (header == 0) {
                            if ((!nextLine[0].equals("ENTRY_ID"))
                                    && (!nextLine[1].equals("DATE"))
                                    && (!nextLine[2].equals("HOUR_OF_DAY"))
                                    && (!nextLine[3].equals("PACKAGE_NAME"))
                                    && (!nextLine[4].equals("UNLOCKS_COUNT"))
                                    && (!nextLine[5].equals("NOTIFICATIONS_COUNT"))
                                    && (!nextLine[6].equals("USAGE_TIME"))) {
                                throw exception;
                            }

                        } else {
                            rowData.add(s);
                        }
                    }
                    if (!rowData.isEmpty()) {
                        Log.i("VALUES", "" + rowData);
                        localDatabase.insert(rowData.get(0), rowData.get(1), rowData.get(2), rowData.get(3), rowData.get(4), rowData.get(5), rowData.get(6));
                    }

                    header++;
                }
                message = "Successfully inserted " + header + " lines";
            } catch (IOException io) {
                message = "Upload Failed";
                Log.i("ERROR", "ERROR:" + io.getMessage());
            } catch (SQLException sql) {
                message = "Invalid or Existing Data";
                Log.i("ERROR", "ERROR:" + sql.getMessage());
            } catch (IllegalArgumentException ia) {
                message = "Invalid Column Headers";
                Log.i("ERROR", "ERROR:" + ia.getMessage());
            }
            return message;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(getContext(), s, Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onResume (){
        super.onResume();
        Log.d("OnResume entered", " entered");
        if (GlobalVariable.dark_mode == true)
        {
            if(getActivity() != null) {
                Log.d("Activity", getActivity().toString());
                RelativeLayout lLayout1 = (RelativeLayout) getActivity().findViewById(R.id.settingslayout);
                lLayout1.setBackgroundColor(Color.parseColor("#4D4E4F"));
            }
        }
        else if(GlobalVariable.dark_mode == false)
        {
            if(getActivity() != null) {
                Log.d("Activity", getActivity().toString());
                RelativeLayout lLayout1 = (RelativeLayout) getActivity().findViewById(R.id.settingslayout);
                lLayout1.setBackgroundColor(Color.parseColor("#FFFFFF"));
            }
        }


    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        Log.d("onSharedPref entered", " entered");
        if (key.toString().equals("toggle_wifi")) {
            if(getActivity() != null) {
                WifiManager wifi = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifi.setWifiEnabled(false);//logic to change Wifi settings

                if (sharedPreferences.getBoolean("toggle_wifi", true) == false) {
                    WifiManager wifi1 = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    wifi1.setWifiEnabled(false);
                    Toast.makeText(getActivity().getApplicationContext(), "DISABLED", Toast.LENGTH_SHORT).show();
                    Log.d("Wifi turned off", "wifi turned off");
                } else if (sharedPreferences.getBoolean("toggle_wifi", true) == true) {
                    WifiManager wifi1 = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    wifi1.setWifiEnabled(true);
                    Toast.makeText(getActivity().getApplicationContext(), "ENABLED", Toast.LENGTH_SHORT).show();
                    Log.d("Wifi turned on", "wifi turned on");
                }
            }
        }

        if (key.toString().equals("dark_mode"))
        {
            if (sharedPreferences.getBoolean("dark_mode", true) == false)
            {
                if(getActivity() != null) {
                    GlobalVariable.dark_mode = false;//logic to change Dark mode settings
                    Log.d("Activity/Dark mode", getActivity().toString());
                    onResume();
//                    ((AppCompatActivity)getActivity()).onResume;
                    Log.d("Dark mode turned off", "Dark mode turned off");
                }
            }

            else if (sharedPreferences.getBoolean("dark_mode", true) == true)
            {
                if(getActivity() != null) {
                    GlobalVariable.dark_mode = true;
                    Log.d("Activity/Dark mode", getActivity().toString());
                    onResume();
                    Log.d("Dark mode turned on", "Dark mode turned on");
                }
            }

        }
        if (key.toString().equals("Data")) {
            if (sharedPreferences.getBoolean("Data", true) == true) {

                setMobileDataEnabled(getActivity().getApplicationContext(), false);
                Toast.makeText(getActivity().getApplicationContext(), "ENABLED", Toast.LENGTH_SHORT).show();
            }
            else {
                    setMobileDataEnabled(getActivity().getApplicationContext(), true);
                    Toast.makeText(getActivity().getApplicationContext(), "DISABLED", Toast.LENGTH_SHORT).show();
                }
            }
        }



    private void setupSharedPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedPreferences.registerOnSharedPreferenceChangeListener(this);
    }


    //the method below enables/disables mobile data depending on the Boolean 'enabled' parameter.
    private void setMobileDataEnabled(Context context, boolean enabled) {
        final ConnectivityManager conman = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        Class conmanClass = null;
        try {
            conmanClass = Class.forName(conman.getClass().getName());
            final Field iConnectivityManagerField = conmanClass.getDeclaredField("mService");
            iConnectivityManagerField.setAccessible(true);
            final Object iConnectivityManager = iConnectivityManagerField.get(conman);
            final Class iConnectivityManagerClass = Class.forName(iConnectivityManager.getClass().getName());
            final Method setMobileDataEnabledMethod = iConnectivityManagerClass.getDeclaredMethod("setMobileDataEnabled", Boolean.TYPE);
            setMobileDataEnabledMethod.setAccessible(true);
            setMobileDataEnabledMethod.invoke(iConnectivityManager, enabled);
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    // below method returns true if mobile data is on and vice versa
    private boolean mobileDataEnabled(Context context){
        boolean mobileDataEnabled = false; // Assume disabled
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            Class cmClass = Class.forName(cm.getClass().getName());
            Method method = cmClass.getDeclaredMethod("getMobileDataEnabled");
            method.setAccessible(true); // Make the method callable
            // get the setting for "mobile data"
            mobileDataEnabled = (Boolean)method.invoke(cm);
        } catch (Exception e) {
            // Some problem accessible private API
            // TODO do whatever error handling you want here
        }
        return mobileDataEnabled;
    }

}
