package com.example.cs491_capstone;

public class GlobalVariable {
    public static boolean dark_mode = false;
    public static MainActivity m;
}
